package com.example.jeffh.androidproject;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PointF;
import android.media.MediaPlayer;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.animation.Interpolator;

public class PopActivity extends AppCompatActivity {

    MediaPlayer winSong;
    boolean showingFirst = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pop);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int width = dm.widthPixels;
        int height = dm.heightPixels;

        getWindow().setLayout((int)(width*.5),(int)(height*.5));
        winSong = MediaPlayer.create(this, R.raw.winsong);
        winSong.start();



    }




    public void nextButton(View view){


        if(showingFirst == true){
            showingFirst = false;
            Intent intent = new Intent(this,GameActivity2.class);
            startActivity(intent);

        }else
        {

            Intent intent = new Intent(this,WaldoActivity.class);
            startActivity(intent);
            showingFirst = true;
        }

        }
    }


