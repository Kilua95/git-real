package com.example.jeffh.androidproject;

import android.content.Intent;
import android.os.Handler;
import android.content.pm.ActivityInfo;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.CountDownTimer;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.VideoView;



public class VideoActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);
        /*if (getResources().getBoolean(R.bool.landscape_only)) {   //Locking activity in Landscape mode
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        }*/
        getWindow().setFormat(PixelFormat.UNKNOWN);
        VideoView mVideo = (VideoView) findViewById(R.id.videoIntro);
        String uriPath2 = "android.resource://com.example.jeffh.androidproject/" + R.raw.video; //Path of the video to be run
        Uri uri2 = Uri.parse(uriPath2);
        mVideo.setVideoURI(uri2);
        mVideo.requestFocus();
        mVideo.start();// Starts video -- VIDEO CAN NO RUN ON EMULATOR BUT PLAYS FINE ON AN ACTUAL ANDROID DEVICE,WAS
                                          //TESTED --


       /* CountDownTimer countDownTimer = new CountDownTimer(9950, 1000) {
            @Override
            public void onTick(long l) {

            }

            @Override
            public void onFinish() {


            }
        }.start();*/

                new Handler().postDelayed(new Runnable() {
                      @Override
                     public void run() {
                          startActivity(new Intent(getApplicationContext(), LoadingActivity.class));
                          //Intent intent = new Intent(VideoActivity.this, WaldoActivity.class);
                          finish();
                          //startActivity(intent);

                     }
                },9500);

        /*final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {

                Intent mInHome = new Intent(VideoActivity.this, WaldoActivity.class);
                VideoActivity.this.startActivity(mInHome);
                finish();
            }
        }, 5000);*/

       /* if (getIntent().getIntExtra("Time", 0) > 0) {
            int time = getIntent().getIntExtra("Time" , 0);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent intent = new Intent(VideoActivity.this, WaldoActivity.class);
                    startActivity(intent);
                    finish();
                }
            }, time * 5000);
        }*/

    }


}






