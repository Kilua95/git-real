package com.example.jeffh.androidproject;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Rect;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.FloatMath;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.Chronometer;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import static com.example.jeffh.androidproject.R.id.chronometer;
import static com.example.jeffh.androidproject.R.id.gameView;
import static com.example.jeffh.androidproject.R.id.simpleChronometer;


public class GameActivity extends AppCompatActivity   {


    private ScaleGestureDetector scaleGestureDetector;
    private ImageView imageView;
    private float mscale = 1f;
    private int currentScore;
    private int highScore;
    private String highScoreString;
    private String currentScoreString;
    private TextView scoreLabel;
    private  TextView highScoreLabel;
    private Chronometer simpleChrono;
    private long startTime ;

    private SharedPreferences msharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        imageView = (ImageView) findViewById(R.id.gameView);
        scoreLabel = (TextView) findViewById(R.id.scoreLabel);
        highScoreLabel = (TextView) findViewById(R.id.highScoreView);

        highScoreString = getString(R.string.high_score);
        currentScoreString = getString(R.string.current_score);

        currentScore = 0;
        scoreLabel.setText(currentScoreString);
        highScoreLabel.setText(highScoreString);

        simpleChrono= (Chronometer) findViewById(R.id.simpleChronometer); // initiate a chronometer
        simpleChrono.start(); // start a chronometer
        this.startTime = System.currentTimeMillis();

        scaleGestureDetector = new ScaleGestureDetector(this, new ScaleListener());






    }


        /*if (getResources().getBoolean(R.bool.landscape_only)) {   //Locking activity in Landscape mode
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        }*/

    public void winButton(View view){
        long difference = (System.currentTimeMillis() - this.startTime)/1000;
        currentScore += difference;
        highScore += difference;
        scoreLabel.setText(currentScoreString + ": " + currentScore);
        highScoreLabel.setText(highScoreString + ": " + highScore);
        startActivity(new Intent(GameActivity.this,PopActivity.class));
        TextView myTextView = (TextView) findViewById(R.id.youWin);
        myTextView.setText("CONGRATULATIONS YOU FOUND CAGE, Time Taken:" + difference +"s");
        myTextView.setVisibility(View.VISIBLE);
        simpleChrono.stop();

    }

    public void imageClick(View view){
                Intent intent = new Intent(this,TimeActivity.class);
                startActivity(intent);
    }



    @Override
    public boolean onTouchEvent(MotionEvent event) {

        scaleGestureDetector.onTouchEvent(event);
        return super.onTouchEvent(event);
    }

    private class ScaleListener implements ScaleGestureDetector.OnScaleGestureListener {
        float onScaleEnd ;

        @Override
        public boolean onScale(ScaleGestureDetector scaleGestureDetector) {

            mscale *= scaleGestureDetector.getScaleFactor();
            imageView.setScaleX(mscale);
            imageView.setScaleY(mscale);
            mscale = Math.max(1.0188f, Math.min(mscale, 8.0f));
            return true;
        }

        @Override
        public boolean onScaleBegin(ScaleGestureDetector scaleGestureDetector) {
            return true;
        }

        @Override
        public void onScaleEnd(ScaleGestureDetector scaleGestureDetector) {
            onScaleEnd = mscale;
            return;
        }


    }

    public void onBackPressed(){

    }


}
