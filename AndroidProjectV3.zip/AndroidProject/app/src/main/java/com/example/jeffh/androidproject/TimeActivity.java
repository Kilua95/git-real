package com.example.jeffh.androidproject;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class TimeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
               finish();

            }
        }, 2000);
    }
}
