package com.example.jeffh.androidproject;

import android.app.Activity;
import android.content.Intent;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.Chronometer;
import android.widget.ImageView;
import android.widget.TextView;

public class GameActivity2 extends AppCompatActivity {

    private ScaleGestureDetector scaleGestureDetector;
    private ImageView imageView;
    private float mscale = 1f;
    private int score = 0;
    private TextView scoreLabel;
    private Chronometer simpleChrono;
    private long startTime ;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game2);

        imageView = (ImageView) findViewById(R.id.gameView);
        scoreLabel = (TextView) findViewById(R.id.scoreLabel);
        simpleChrono= (Chronometer) findViewById(R.id.simpleChronometer); // initiate a chronometer
        simpleChrono.start(); // start a chronometer
        this.startTime = System.currentTimeMillis();

        scaleGestureDetector = new ScaleGestureDetector(this, new GameActivity2.ScaleListener());


                scoreLabel.setText("Score : 0");

}


        /*if (getResources().getBoolean(R.bool.landscape_only)) {   //Locking activity in Landscape mode
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        }*/

    public void winButton2(View view){
        score += 10;
        scoreLabel.setText("Score : " + score);
        long difference = System.currentTimeMillis() - this.startTime;
        startActivity(new Intent(this,PopActivity.class));
        TextView myTextView = (TextView) findViewById(R.id.youWin);
        System.out.print(difference);
        myTextView.setText("CONGRATULATIONS YOU WON, Time Taken:" + difference);
        simpleChrono.stop();
    }



    public void imageClick(View view){
        Intent intent = new Intent(this,TimeActivity.class);
        startActivity(intent);

    }
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleGestureDetector.onTouchEvent(event);
        return super.onTouchEvent(event);
    }

private class ScaleListener implements ScaleGestureDetector.OnScaleGestureListener {
    float onScaleEnd ;

    @Override
    public boolean onScale(ScaleGestureDetector scaleGestureDetector) {

        mscale *= scaleGestureDetector.getScaleFactor();
        imageView.setScaleX(mscale);
        imageView.setScaleY(mscale);
        mscale = Math.max(1.0188f, Math.min(mscale, 8.0f));
        return true;
    }

    @Override
    public boolean onScaleBegin(ScaleGestureDetector scaleGestureDetector) {
        return true;
    }

    @Override
    public void onScaleEnd(ScaleGestureDetector scaleGestureDetector) {
        onScaleEnd = mscale;
        return;
    }
}

}
