package com.example.jeffh.androidproject;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class helpActivity extends AppCompatActivity {


    MediaPlayer bkgrdmu ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        /*if (getResources().getBoolean(R.bool.portrait_only)) {   //Locking activity in portrait mode
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }*/

        TextView myAwesomeTextView = (TextView)findViewById(R.id.textView2);
        myAwesomeTextView.setText("IT's time to find the world's most elusive traveling hero!\n\n\t" +
                "Cage wants to wander across the moon and he needs your help to get there." +
                "Search for him amidst scores of people in a multitude of detailed settings. \n\n\t" +
                "Will he be standing near the carrousel at the fairground? " +
                "But wait, is that him poking his head out of a manhole or hiding in the back of a truck? \n\n\t" +
                "Is he racing through the streets of the city in a sports car or dodging traffic as a pedestrian? " +
                "Where is Cage?\n");

        bkgrdmu = MediaPlayer.create(helpActivity.this, R.raw.song);
        bkgrdmu.setLooping(true);
        bkgrdmu.start();

    }

        public void onBackPressed(){

        }


        public void back(View view) {
            Intent startNewActivity = new Intent(this, WaldoActivity.class);
            startActivity(startNewActivity);
            bkgrdmu.release();
            finish();
        }

}
