package com.example.jeffh.androidproject;


import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.View;


public class WaldoActivity extends AppCompatActivity {

    MediaPlayer bkgrdmu ;


            @Override
            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_waldo);


                /*if (getResources().getBoolean(R.bool.portrait_only)) {   //Locking activity in portrait mode
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                }*/

                bkgrdmu = MediaPlayer.create(WaldoActivity.this, R.raw.song);
                bkgrdmu.setLooping(true);
                bkgrdmu.start();

            }

            public void startGame(View view){
                Intent startgame = new Intent(this,GameActivity.class);
                startActivity(startgame);
                finish();
            }

            public void onPause(){
                super.onPause();
                bkgrdmu.release();
                finish();
            }

            public void help(View view){
                Intent startNewActivity = new Intent(this, helpActivity.class);
                startActivity(startNewActivity);
                finish();
            }

            public void onBackPressed(){

            }

            public void exit(View view) {


                        final AlertDialog.Builder builder = new AlertDialog.Builder(WaldoActivity.this);
                        builder.setIcon(R.drawable.cage2);
                        builder.setTitle("Do you really want to exit?");
                        builder.setCancelable(false);
                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int id) {
                                finish();
                            }
                        });
                        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int id) {
                              dialogInterface.dismiss();
                            }
                        });
                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();

                    }


}






